#!/bin/bash
cat ref.softhsm
cat ref.proxy
mkdir -p /usr/local/lib/softhsm/
mkdir -p /config/
mkdir -p /usr/local/etc/nitrokey/
cp nethsm-pkcs11-vv1.5.0-x86_64-debian.12.so /usr/local/lib/softhsm/libpkcs11-proxy.so
cp pkcs11.cfg /config/softhsm-application.conf
cp p11nethsm.conf /usr/local/etc/nitrokey/p11nethsm.conf
